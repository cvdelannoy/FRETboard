
class MainTable(object):
    '''
    Placeholder for a MainTable object, if initialization of the entire table is not necessary.
    '''
    def __init__(self, eps, l, d, gamma, alex, traceswitch):
        self.eps, self.l, self.d, self.gamma, self.alex, self.traceswitch = eps, l, d, gamma, alex, traceswitch